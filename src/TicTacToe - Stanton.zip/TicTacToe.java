public class TicTacToe {
    public static void main(String[] args) {
        Game g1 = new Game();
        g1.gameLoop();
    }
}
